﻿

namespace ProjSecDemo.Data
{
    public class Personne
    {
        public int id { get; set; }

        public string LastName { get; set; } = string.Empty;

        public string FirstName { get; set; } = string.Empty;

    }
}
